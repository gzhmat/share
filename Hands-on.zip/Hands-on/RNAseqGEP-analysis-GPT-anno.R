# Clear existing variables from the R environment to ensure a clean workspace
rm(list=ls())

# Set the working directory to the location of the currently active RStudio document
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Source an external script that installs required packages (assumed to check for and install missing packages)
source("./etc/install.R")

# Load necessary libraries for data manipulation, statistical analysis, and visualization
library(DESeq2)       # For differential expression analysis
library(dplyr)        # For data manipulation
library(magrittr)     # For more readable piping operations
library(RColorBrewer) # For generating color palettes
library(matrixStats)  # For matrix operations
library(Rtsne)        # For t-SNE dimensionality reduction
library(pheatmap)     # For plotting heatmaps
library(ggpubr)       # For enhancing ggplot2 plots
library(sva)          # For batch effect correction
library(caret)        # For general data analysis and modeling

# File paths for sample information and gene annotation
sampleInforFile="./inputMeta.txt"
geneAnnotationFile="./etc/Homo_sapiens.GRCh38.V102.summary.txt"
highCorrCutoff=0.95

# Load and prepare sample information and gene annotation data
sampleInfor=read.table(sampleInforFile, sep = "\t", header = TRUE, as.is = TRUE)
geneAnnotation=read.table(geneAnnotationFile, sep = "\t", header = TRUE, as.is = TRUE) %>% set_rownames(.$gene_id)

# Construct a sample table required by DESeq2 for analysis
sampleTable=data.frame(sampleName=sampleInfor$sample, fileName=sampleInfor$path)

# Create a DESeq2 dataset object using HTSeq count data
ddsHTSeq_raw=DESeqDataSetFromHTSeqCount(sampleTable = sampleTable, design= ~ 1)

# Filter genes: Keep genes with at least N (here, 1) samples having >= 10 reads
sampleHighCountMin = 1
geneCountMin=10
geneHighExprIdx = apply(X = counts(ddsHTSeq_raw), MARGIN = 1, FUN = function(x) sum(x>=geneCountMin)) >= sampleHighCountMin
ddsHTSeqHighExpr <- ddsHTSeq_raw[geneHighExprIdx, ]

# Perform variance stabilizing transformation on the filtered DESeq2 dataset
geneExprTransformation <- varianceStabilizingTransformation(ddsHTSeqHighExpr, blind=TRUE)

# Round and annotate the normalized expression data
geneExprVstNormDF=assay(geneExprTransformation) %>% as.data.frame() %>% round(., digits = 4) %>% 
  bind_cols(geneAnnotation[rownames(.),]) %>% select(!starts_with("COH"), everything())

# Separate expression values and metadata for further analysis
geneExprValue=geneExprVstNormDF %>% select(starts_with("COH"))
geneExprMeta=geneExprVstNormDF %>% select(!starts_with("COH"))

# Define a function to visualize the distribution of variance-stabilized expression values
geneExporVstDist <- function(df){
  sampleNum=ncol(geneExprValue)
  sampleCol=rainbow(sampleNum, alpha = 0.6)
  dens.x=c()
  dens.y=c()
  maxY=0
  for( i in 1:sampleNum){
    sampleI=df[,i]
    density=density(sampleI, from=-5, to=20 )
    maxY=ifelse(maxY > max(density$y), maxY, max(density$y))
    dens.x=cbind(dens.x, density$x)
    dens.y=cbind(dens.y, density$y)
  }
  plot(1,1, type='n', ylim=c(0,1.2*maxY), xlim=c(-2,18), xlab = "rlog value", ylab="Density", main = "" )
  for( i in 1:sampleNum){
    points(dens.x[,i], dens.y[,i], type = "l", col=sampleCol[i])
  }
  densX=rowMedians(dens.x)
  densY=rowMedians(dens.y)
  points(densX, densY, type='l', lwd = 2)
}  
# Call the function to plot distribution of variance-stabilized expression values
geneExporVstDist(geneExprValue)

# Assign colors to different subtypes for visualization
subtypes = unique(sampleInfor$subtype)
subtypeColors = brewer.pal(length(subtypes), "Paired") %>% set_names(subtypes)

# Filter out genes located on chromosomes X, Y, and mitochondrial DNA to remove potential sex and mitochondrial biases
exprData_noChrXYM=geneExprVstNormDF %>% filter(!chr %in% c("chrX", "chrY", "chrM")) %>%  select(starts_with("COH"))

# Further filter to remove lowly expressed genes
geneExprMin=5
exprData_noXYMT_exprHigh=exprData_noChrXYM[rowMaxs(as.matrix(exprData_noChrXYM), useNames = FALSE ) >= geneExprMin, ]

# Order genes by median absolute deviation (MAD) to identify the most variably expressed genes
exprData_noXYMT_exprHigh_madOrd = data.frame(gene_ID=rownames(exprData_noXYMT_exprHigh),
                                             mad=rowMads(as.matrix(exprData_noXYMT_exprHigh), useNames = FALSE)) %>% arrange(desc(mad))

# Select a subset of genes with the highest MAD for further analysis
geneNum_init=2000
topMadGenes=exprData_noXYMT_exprHigh_madOrd$gene_ID[1:geneNum_init]
exprData_noXYMT_exprHigh_topMad=exprData_noXYMT_exprHigh[topMadGenes,]

# Identify and remove highly correlated genes to reduce redundancy and potential multicollinearity in the data
modelDF=t(exprData_noXYMT_exprHigh_topMad) %>% as.data.frame()
corrMatrix = cor(modelDF)
highCorrIdx = findCorrelation(corrMatrix, cutoff=highCorrCutoff)
highCorrGenes=colnames(modelDF[, highCorrIdx])
modelDFnoCorr=modelDF[, -highCorrIdx]
noHighCorrGeneDF=t(modelDFnoCorr)

# Perform t-SNE clustering on cleaned and filtered expression data to visualize patterns and potential clusters
geneMadOrd = data.frame(gene_ID=rownames(noHighCorrGeneDF),
                        mad=rowMads(as.matrix(noHighCorrGeneDF), useNames = FALSE)) %>% arrange(desc(mad))
geneNum=1000
expMadGenes = geneMadOrd$gene_ID[1:geneNum]
exprData_clean=noHighCorrGeneDF[expMadGenes,]

topMadDataTv=t(exprData_clean) %>% set_rownames(c())
Perp=10
set.seed(0) # Ensure reproducibility by setting a random seed
cat("Perplexity:", Perp, "; top MAD gene number:", geneNum, "\n");
tsneOut = Rtsne(topMadDataTv, dims = 2, perplexity = Perp, theta = 0.5, max_iter = 2500, check_duplicates = FALSE,
                pca=TRUE, partial_pca=FALSE, initial_dims=50, num_threads = 6) # Execute t-SNE analysis

# Prepare data for visualization, including t-SNE dimensions and sample metadata
tsneDF=sampleInfor %>% mutate(X=tsneOut$Y[,1], Y=tsneOut$Y[,2], subtype = factor(subtype)) 

# Plot t-SNE results to visualize clusters by subtype and library batch using ggplot2
(gpSubtypeBatch=ggplot() + xlab(paste0("top MAD gene num = ", geneNum, "; perplexity=", Perp)) + ylab("")+
    geom_point(data=tsneDF, aes(X, Y, color=subtype))+
    theme_bw() +
    scale_color_manual(values = subtypeColors, limits = force) +
    theme(axis.text = element_blank(), axis.ticks=element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
)

# Color-coding for different libraries
libraries=unique(sampleInfor$library)
libraryColors=c("grey40", "orangered") %>% set_names(libraries)
(gpLibraryBatch=ggplot() + xlab(paste0("top MAD gene num = ", geneNum, "; perplexity=", Perp)) + ylab("")+
    geom_point(data=tsneDF, aes(X, Y, color=library))+
    theme_bw() +
    scale_color_manual(values = libraryColors, limits = force) +
    theme(axis.text = element_blank(), axis.ticks=element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
)

# Arrange the ggplot objects for subtype and library batches side by side for comparison
ggarrange(gpSubtypeBatch, gpLibraryBatch, ncol = 2, nrow = 1, common.legend = FALSE)

# Annotate the heatmap with sample information (subtype and library) and define custom colors for annotations
annotation_col = sampleInfor %>% select(subtype, library) %>% set_rownames(sampleInfor$sample)
ann_colors = list(subtype = subtypeColors, library = libraryColors)

# Plot a heatmap of the cleaned and filtered expression data, highlighting gene expression patterns and sample annotations
pheatmap(exprData_clean, annotation_legend = TRUE, cluster_cols = TRUE, clustering_distance_cols = "correlation",
         clustering_method= "ward.D2", border_color = NA, scale = 'row', show_rownames = FALSE, show_colnames = FALSE,
         annotation_col = annotation_col, annotation_colors = ann_colors)




# Batch effect correction using ComBat to adjust for non-biological technical variations
raw_vst_exprDF=geneExprValue
raw_vst_meta=geneExprMeta
modcombat = model.matrix(~1, data=sampleInfor) # Model for batch effect adjustment
batch=sampleInfor$library # Batch variable
set.seed(1) # Ensure reproducibility
exprDataCombat = ComBat(dat=as.matrix(geneExprValue), batch=batch, mod=modcombat, par.prior=TRUE) %>% 
  as.data.frame() %>% round(., digits = 2) # Execute batch effect correction

# Combine corrected expression data with metadata for further analysis
vst_exprDF=raw_vst_meta %>% bind_cols(exprDataCombat)

# Repeat the filtering and cleaning process on the batch-corrected data for consistency
exprData_noXYMT=vst_exprDF %>% filter(!chr %in% c("chrX", "chrY", "chrM")) %>%  select(starts_with("COH"))
exprData_noXYMT_exprHigh=exprData_noXYMT[rowMaxs(as.matrix(exprData_noXYMT), useNames = FALSE) >= geneExprMin, ]
exprData_noXYMT_exprHigh_madOrd = data.frame(gene_ID=rownames(exprData_noXYMT_exprHigh),
                                             mad=rowMads(as.matrix(exprData_noXYMT_exprHigh), useNames = FALSE)) %>% arrange(desc(mad))
topMadGenes=exprData_noXYMT_exprHigh_madOrd$gene_ID[1:geneNum_init]
exprData_noXYMT_exprHigh_topMad=exprData_noXYMT_exprHigh[topMadGenes,]

# Identifying and removing highly correlated genes in the batch-corrected data
modelDF=t(exprData_noXYMT_exprHigh_topMad) %>% as.data.frame()
corrMatrix = cor(modelDF)
highCorrIdx = findCorrelation(corrMatrix, cutoff=highCorrCutoff)
highCorrGenes=colnames(modelDF[, highCorrIdx])
modelDFnoCorr=modelDF[, -highCorrIdx]
noHighCorrGeneDF=t(modelDFnoCorr)

# Perform t-SNE analysis on the batch-corrected, filtered data to assess the impact of batch effect correction on data clustering
geneMadOrd = data.frame(gene_ID=rownames(noHighCorrGeneDF), mad=rowMads(as.matrix(noHighCorrGeneDF), useNames = FALSE)) %>% arrange(desc(mad))
expMadGenes = geneMadOrd$gene_ID[1:geneNum]
exprData_clean=noHighCorrGeneDF[expMadGenes,]

topMadDataTv=t(exprData_clean) %>% set_rownames(c())
set.seed(0) # Ensure reproducibility
cat("Perplexity:", Perp, "; top MAD gene number:", geneNum, "\n");
tsneOut = Rtsne(topMadDataTv, dims = 2, perplexity = Perp, theta = 0.5, max_iter = 2500, check_duplicates = FALSE,
                pca=TRUE, partial_pca=FALSE, initial_dims=50, num_threads = 6) # Execute t-SNE analysis
tsneDF=sampleInfor %>% mutate(X=tsneOut$Y[,1], Y=tsneOut$Y[,2], subtype = factor(subtype))

# Visualization of t-SNE clustering post-batch effect correction
(gpSubtypeNoBatch=ggplot() + xlab(paste0("top MAD gene num = ", geneNum, "; perplexity=", Perp)) + ylab("")+
    geom_point(data=tsneDF, aes(X, Y, color=subtype))+
    theme_bw() +
    scale_color_manual(values = subtypeColors, limits = force) +
    theme(axis.text = element_blank(), axis.ticks=element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
)
(gpLibraryNoBatch=ggplot() + xlab(paste0("top MAD gene num = ", geneNum, "; perplexity=", Perp)) + ylab("")+
    geom_point(data=tsneDF, aes(X, Y, color=library))+
    theme_bw() +
    scale_color_manual(values = libraryColors, limits = force) +
    theme(axis.text = element_blank(), axis.ticks=element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
)

# Arrange all ggplot objects to compare pre- and post-batch effect correction clustering
ggarrange(gpSubtypeBatch, gpLibraryBatch, gpSubtypeNoBatch, gpLibraryNoBatch, ncol = 2, nrow = 2, common.legend = FALSE)

# Plot a heatmap of the batch-corrected, cleaned, and filtered expression data to assess expression patterns and sample annotations
pheatmap(exprData_clean, annotation_legend = TRUE, cluster_cols = TRUE, clustering_distance_cols = "correlation",
         clustering_method= "ward.D2", border_color = NA, scale = 'row', show_rownames = FALSE, show_colnames = FALSE,
         annotation_col = annotation_col, annotation_colors = ann_colors)
