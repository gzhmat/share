rm(list=ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
source("./etc/install.R")
library(DESeq2)
library(dplyr)
library(magrittr)
library(RColorBrewer)
library(matrixStats)
library(Rtsne)
library(pheatmap)
library(ggpubr)
library(sva)
library(caret)


sampleInforFile="./inputMeta.txt"
geneAnnotationFile="./etc/Homo_sapiens.GRCh38.V102.summary.txt"
highCorrCutoff=0.95

sampleInfor=read.table(sampleInforFile, sep = "\t", header = T, as.is = T)
geneAnnotation=read.table(geneAnnotationFile, sep = "\t", header = T, as.is = T) %>% set_rownames(.$gene_id)

#sampleTable:
#Each row describes one sample. The first column is the sample name, the second column the file path
sampleTable=data.frame(sampleName=sampleInfor$sample,
                       fileName=sampleInfor$path)
ddsHTSeq_raw=DESeqDataSetFromHTSeqCount(sampleTable = sampleTable, design= ~ 1)

#keep the genes with at least N samples covered by >= 10 reads
sampleHighCountMin = 1
geneCountMin=10
geneHighExprIdx = apply(X = counts(ddsHTSeq_raw)
                                   , MARGIN = 1
                                   , FUN = function(x) sum(x>=geneCountMin)
                                   ) >= sampleHighCountMin
  

ddsHTSeqHighExpr <- ddsHTSeq_raw[geneHighExprIdx, ]
geneExprTransformation <- varianceStabilizingTransformation(ddsHTSeqHighExpr, blind=T)

geneExprVstNormDF=assay(geneExprTransformation) %>% as.data.frame() %>% round(., digits = 4) %>% 
  bind_cols(geneAnnotation[rownames(.),]) %>% select(!starts_with("COH"), everything())

geneExprValue=geneExprVstNormDF %>% select(starts_with("COH"))
geneExprMeta=geneExprVstNormDF %>% select(!starts_with("COH"))

#check VST expression distribution using density plot
#put this code block as a separate function
geneExporVstDist <- function(df){
  sampleNum=ncol(geneExprValue)
  sampleCol=rainbow(sampleNum, alpha = 0.6)
  dens.x=c()
  dens.y=c()
  maxY=0;
  for( i in 1:sampleNum){
    sampleI=df[,i]
    density=density(sampleI, from=-5, to=20 )
    maxY=ifelse(maxY > max(density$y), maxY, max(density$y));
    dens.x=cbind(dens.x, density$x)
    dens.y=cbind(dens.y, density$y)
  }
  plot(1,1, type='n', ylim=c(0,1.2*maxY), xlim=c(-2,18), xlab = "rlog value", ylab="Density", main = "" )
  for( i in 1:sampleNum){
    points(dens.x[,i], dens.y[,i], type = "l", col=sampleCol[i]);
  }
  densX=rowMedians(dens.x)
  densY=rowMedians(dens.y)
  points(densX, densY, type='l', lwd = 2)
}  
#call the function
geneExporVstDist(geneExprValue)

#assign colors for the subtypes
subtypes = unique(sampleInfor$subtype)
subtypeColors = brewer.pal(length(subtypes), "Paired") %>% set_names(subtypes)


#remove genes on chr X, Y and MT
exprData_noChrXYM=geneExprVstNormDF %>% filter(!chr %in% c("chrX", "chrY", "chrM")) %>%  select(starts_with("COH"))
#remove lowly expressed genes
geneExprMin=10
exprData_noXYMT_exprHigh=exprData_noChrXYM[rowMaxs(as.matrix(exprData_noChrXYM)) >= geneExprMin, ]
exprData_noXYMT_exprHigh_madOrd = data.frame(gene_ID=rownames(exprData_noXYMT_exprHigh),
                                             mad=rowMads(as.matrix(exprData_noXYMT_exprHigh))) %>% arrange(desc(mad))
####remove low mad genes####
geneNum_init=2000
topMadGenes=exprData_noXYMT_exprHigh_madOrd$gene_ID[1:geneNum_init]
exprData_noXYMT_exprHigh_topMad=exprData_noXYMT_exprHigh[topMadGenes,]

####remove high corr genes####
# find attributes that are highly corrected
modelDF=t(exprData_noXYMT_exprHigh_topMad) %>% as.data.frame()
corrMatrix = cor(modelDF)
highCorrIdx = findCorrelation(corrMatrix, cutoff=highCorrCutoff)
highCorrGenes=colnames(modelDF[, highCorrIdx])
modelDFnoCorr=modelDF[, -highCorrIdx]
noHighCorrGeneDF=t(modelDFnoCorr)
#for t-SNE cluster
geneMadOrd = data.frame(gene_ID=rownames(noHighCorrGeneDF),
                        mad=rowMads(as.matrix(noHighCorrGeneDF))) %>% arrange(desc(mad))
geneNum=1000
expMadGenes = geneMadOrd$gene_ID[1:geneNum]
exprData_clean=noHighCorrGeneDF[expMadGenes,]

topMadDataTv=t(exprData_clean) %>% set_rownames(c())
Perp=10
set.seed(0) # Sets seed for reproducibility
cat("Perplexity:", Perp, "; top MAD gene number:", geneNum, "\n");
tsneOut = Rtsne(topMadDataTv, dims = 2, perplexity = Perp, theta = 0.5, max_iter = 2500, check_duplicates = F,
                pca=T, partial_pca=F, initial_dims=50, num_threads = 6) # Run TSNE
tsneDF=sampleInfor %>% mutate(X=tsneOut$Y[,1], Y=tsneOut$Y[,2], subtype = factor(subtype) ) 

(gpSubtypeBatch=ggplot() + xlab(paste0("top MAD gene num = ", geneNum, "; perplexity=", Perp)) + ylab("")+
    geom_point(data=tsneDF, aes(X, Y, color=subtype))+
    theme_bw() +
    scale_color_manual(values = subtypeColors, limits = force) +
    theme(axis.text = element_blank(), axis.ticks=element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
)

libraries=unique(sampleInfor$library)
libraryColors=c("grey40", "orangered") %>% set_names(libraries)
(gpLibraryBatch=ggplot() + xlab(paste0("top MAD gene num = ", geneNum, "; perplexity=", Perp)) + ylab("")+
    geom_point(data=tsneDF, aes(X, Y, color=library))+
    theme_bw() +
    scale_color_manual(values = libraryColors, limits = force) +
    theme(axis.text = element_blank(), axis.ticks=element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
)

ggarrange(gpSubtypeBatch, gpLibraryBatch,
          ncol = 2, nrow = 1,
          common.legend = F
)

annotation_col = sampleInfor %>% select(subtype, library) %>% set_rownames(sampleInfor$sample)
ann_colors = list(
  subtype = subtypeColors,
  library = libraryColors
)

pheatmap(exprData_clean
         , annotation_legend = T
         , cluster_cols = T
         , clustering_distance_cols = "correlation"
         , clustering_method= "ward.D2"
         , border_color = NA
         , scale = 'row'
         , show_rownames = F
         , show_colnames = F
         , annotation_col = annotation_col
         , annotation_colors = ann_colors
         
)


# #batch effect correction
modcombat = model.matrix(~1, data=sampleInfor)
# correct library batch effect
batch=sampleInfor$library

raw_vst_exprDF=geneExprValue
raw_vst_meta=geneExprMeta
set.seed(1)
exprDataCombat = ComBat(dat=as.matrix(raw_vst_exprDF), batch=batch, mod=modcombat, par.prior=TRUE) %>%
  as.data.frame() %>% round(., digits = 2)
# 
vst_exprDF=raw_vst_meta %>% bind_cols(exprDataCombat)


#remove genes on chr X, Y and MT
exprData_noXYMT=vst_exprDF %>% filter(!chr %in% c("chrX", "chrY", "chrM")) %>%  select(starts_with("COH"))
####remove consistantly low-expressed genes####
geneExprMin=10
exprData_noXYMT_exprHigh=exprData_noXYMT[rowMaxs(as.matrix(exprData_noXYMT)) >= geneExprMin, ]
exprData_noXYMT_exprHigh_madOrd = data.frame(gene_ID=rownames(exprData_noXYMT_exprHigh),
                                             mad=rowMads(as.matrix(exprData_noXYMT_exprHigh))) %>% arrange(desc(mad))
####remove low mad genes####
geneNum_init=2000
topMadGenes=exprData_noXYMT_exprHigh_madOrd$gene_ID[1:geneNum_init]
exprData_noXYMT_exprHigh_topMad=exprData_noXYMT_exprHigh[topMadGenes,]

####remove high corr genes####
# find attributes that are highly corrected
modelDF=t(exprData_noXYMT_exprHigh_topMad) %>% as.data.frame()
corrMatrix = cor(modelDF)
highCorrIdx = findCorrelation(corrMatrix, cutoff=highCorrCutoff)
highCorrGenes=colnames(modelDF[, highCorrIdx])
modelDFnoCorr=modelDF[, -highCorrIdx]
noHighCorrGeneDF=t(modelDFnoCorr)
#for t-SNE cluster
geneMadOrd = data.frame(gene_ID=rownames(noHighCorrGeneDF),
                        mad=rowMads(as.matrix(noHighCorrGeneDF))) %>% arrange(desc(mad))
geneNum=1000
expMadGenes = geneMadOrd$gene_ID[1:geneNum]
exprData_clean=noHighCorrGeneDF[expMadGenes,]

topMadDataTv=t(exprData_clean) %>% set_rownames(c())
Perp=10
set.seed(0) # Sets seed for reproducibility
cat("Perplexity:", Perp, "; top MAD gene number:", geneNum, "\n");
tsneOut = Rtsne(topMadDataTv, dims = 2, perplexity = Perp, theta = 0.5, max_iter = 2500, check_duplicates = F,
                pca=T, partial_pca=F, initial_dims=50, num_threads = 6) # Run TSNE
tsneDF=sampleInfor %>% mutate(X=tsneOut$Y[,1], Y=tsneOut$Y[,2], subtype = factor(subtype) ) 
(gpSubtypeNoBatch=ggplot() + xlab(paste0("top MAD gene num = ", geneNum, "; perplexity=", Perp)) + ylab("")+
    geom_point(data=tsneDF, aes(X, Y, color=subtype))+
    theme_bw() +
    scale_color_manual(values = subtypeColors, limits = force) +
    theme(axis.text = element_blank(), axis.ticks=element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
)
(gpLibraryNoBatch=ggplot() + xlab(paste0("top MAD gene num = ", geneNum, "; perplexity=", Perp)) + ylab("")+
    geom_point(data=tsneDF, aes(X, Y, color=library))+
    theme_bw() +
    scale_color_manual(values = libraryColors, limits = force) +
    theme(axis.text = element_blank(), axis.ticks=element_blank(),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank())
)


ggarrange(gpSubtypeBatch, gpLibraryBatch, gpSubtypeNoBatch, gpLibraryNoBatch
          ,ncol = 2, nrow = 2
          ,common.legend = F
)

pheatmap(exprData_clean
         , annotation_legend = T
         , cluster_cols = T
         , clustering_distance_cols = "correlation"
         , clustering_method= "ward.D2"
         , border_color = NA
         , scale = 'row'
         , show_rownames = F
         , show_colnames = F
         , annotation_col = annotation_col
         , annotation_colors = ann_colors
         
)
