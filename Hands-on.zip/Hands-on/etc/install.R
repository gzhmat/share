list.of.packages = c("rstudioapi", "magrittr", "RColorBrewer", "dplyr", "matrixStats", "Rtsne", "pheatmap", "sva", "caret", "ggpubr")
new.packages = list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages))
  install.packages(new.packages)

# Check if DESeq2 is installed
if (!requireNamespace("DESeq2", quietly = TRUE)) {
  # Install Bioconductor if not installed
  if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
  # Install DESeq2
  BiocManager::install("DESeq2")
}

# Check if DESeq2 is installed
if (!requireNamespace("sva", quietly = TRUE)) {
  # Install Bioconductor if not installed
  if (!requireNamespace("BiocManager", quietly = TRUE))
    install.packages("BiocManager")
  # Install DESeq2
  BiocManager::install("sva")
}